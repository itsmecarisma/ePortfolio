package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;
import appointmentservice.Appointment;
import appointmentservice.AppointmentService;

public class AppointmentServiceTest {

    @Test
    public void testDelete() {
        // Create a Date and Description for appointments
        Date date = new Date();
        String description = "Empty bladder before appointment";

        // Initialize an AppointmentService instance
        AppointmentService cs = new AppointmentService();

        // Create three test Appointments
        Appointment test1 = new Appointment(date, description);
        Appointment test2 = new Appointment(date, description);
        Appointment test3 = new Appointment(date, description);

        // Add the test Appointments to the AppointmentService
        cs.addAppointment(test1);
        cs.addAppointment(test2);
        cs.addAppointment(test3);

        // Test deleting an existing appointment (test1)
        assertTrue(cs.deleteAppointment(test1.getID()));

        // Test deleting a non-existent appointment ("584975120097")
        assertFalse(cs.deleteAppointment("584975120097"));
    }
}




