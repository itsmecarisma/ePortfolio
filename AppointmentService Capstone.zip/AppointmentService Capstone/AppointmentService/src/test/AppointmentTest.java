package test;

import java.util.Date;
import org.junit.jupiter.api.Test;
import appointmentservice.Appointment;
import static org.junit.Assert.assertEquals;

public class AppointmentTest {
    
    @Test
    void testAppointment() {
        // Create a description for the appointment
        String description = "Empty bladder before appointment";
        
        // Create a Date object representing the appointment date and time
        Date date = new Date();
        
        // Create an instance of the Appointment class
        Appointment appointment = new Appointment(date, description);
        
        // Use JUnit's assertEquals to compare the actual and expected values
        // In this case, we are comparing the description we set with what we retrieve from the appointment object
        assertEquals(description, appointment.getDescription());
    }
}

