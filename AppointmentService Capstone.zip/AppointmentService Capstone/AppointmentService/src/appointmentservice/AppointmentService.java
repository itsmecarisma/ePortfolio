package appointmentservice;

import java.util.ArrayList;

public class AppointmentService {
    // Holds the list of appointments
    private final ArrayList<Appointment> appointments;

    public AppointmentService() {
        // Initialize the array list
        appointments = new ArrayList<>();
    }

    // Method to add an appointment
    public void addAppointment(Appointment appointment) {
        boolean isInArray = false;
        // Loop through all the appointments
        for (Appointment appointmentObject : appointments) {
            // Check if the appointment object is in the array
            if (appointmentObject.equals(appointment)) {
                isInArray = true;
                break;
            }
        }
        // If the appointment is not in the array, add it
        if (!isInArray) {
            appointments.add(appointment);
            // Returns true if the appointment was added successfully
        }
        // Returns false if the appointment was not added successfully
    }

    // Method to find the appointment by id
    public Appointment getAppointment(String id) {
        for (Appointment appointmentObject : appointments) {
            // Check if there is an appointment with that id
            if (appointmentObject.getID().equals(id)) {
                return appointmentObject;
            }
        }
        return null;
    }

    // Method to delete an appointment by id
    public boolean deleteAppointment(String id) {
        for (Appointment appointmentObject : appointments) {
            // Check if there is an appointment with that id
            if (appointmentObject.getID().equals(id)) {
                appointments.remove(appointmentObject);
                return true;
            }
        }
        return false;
    }
}


