package appointmentservice;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

public class Appointment {
    private String appointmentid;
    private LocalDate appointmentdate;
    private String description;

    private static final int ID_LENGTH = 10;
    private static final int DESCRIPTION_LENGTH = 50;

    public String getID() {
        return appointmentid;
    }

    public LocalDate getDate() {
        return appointmentdate;
    }

    public String getDescription() {
        return description;
    }

    protected void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("Description must not be null. Please provide a valid description.");
        } else if (description.length() > DESCRIPTION_LENGTH) {
            throw new IllegalArgumentException("Description must not exceed " +
                    DESCRIPTION_LENGTH + " characters. Please shorten the description.");
        }
        this.description = description;
    }

    protected void setDate(LocalDate date) {
        if (date == null) {
            throw new IllegalArgumentException("Date must not be null. Please provide a valid date.");
        } else if (date.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past. Please select a future date.");
        }
        this.appointmentdate = date;
    }

    // Constructor using Date and description
    public Appointment(Date date, String description) {
        setUniqueId();
        setDate(convertToLocalDate(date));
        setDescription(description);

        // Print the appointment details for debugging
        System.out.println(this.toString());
    }

    private void setUniqueId() {
        String uuid = UUID.randomUUID().toString();
        this.appointmentid = uuid.substring(0, ID_LENGTH);
    }

    private LocalDate convertToLocalDate(Date date) {
        return new java.sql.Date(date.getTime()).toLocalDate();
    }

    @Override
    public String toString() {
        return "Appointment: ID=" + appointmentid + ", date=" + appointmentdate + ", description=" + description;
    }
}
